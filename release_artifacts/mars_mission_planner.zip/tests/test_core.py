from mission_planner.core import MissionInput, build_plan, score_risk

def test_score_risk_low():
    inp = MissionInput(payload_mass_kg=1200, orbit_altitude_km=450, launch_window_hours=6)
    assert score_risk(inp) < 0.35

def test_build_plan_has_keys():
    inp = MissionInput(payload_mass_kg=6000, orbit_altitude_km=900, launch_window_hours=1.5)
    plan = build_plan(inp)
    assert 'risk_score' in plan
    assert 'risk_band' in plan
